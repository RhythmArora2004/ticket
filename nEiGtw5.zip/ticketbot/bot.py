import discord
import json
from discord import *
from discord.ext import commands, tasks
from cogs.ticket_system import Ticket_System
from cogs.ticket_commands import Ticket_Command

with open("config.json", "r") as file:
    data = json.load(file)

BOT_TOKEN = data["token"]
GUILD_ID = data["server_id"]
CATEGORY_ID1 = data["category_id_1"]
CATEGORY_ID2 = data["category_id_2"]

bot = commands.Bot(intents=discord.Intents.all())

@bot.event
async def on_ready():
    print(f'Bot Logged in as {bot.user.name}')
    print("Made by @suspectedesp2 on Discord (woah)")
    
bot.add_cog(Ticket_System(bot))
bot.add_cog(Ticket_Command(bot))
bot.run(BOT_TOKEN)
